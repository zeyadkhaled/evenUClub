package com.bilkentazure.evenuclub.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bilkentazure.evenuclub.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {


//	ListView list;
	String[] web = {
			"Java",
			"C++",
			"C#",
			"HTML",
			"CSS"
	} ;
	Integer[] imageId = {
			R.drawable.about_icon_twitter,
			R.drawable.about_icon_instagram,
			R.drawable.about_icon_github,
			R.drawable.about_icon_facebook,
			R.drawable.about_icon_email
	};

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fragment_home, container, false);
		return view;

//		CustomList listAdapter = new CustomList(HomeFragment.this, web, imageId);
//		list=(ListView)findViewById(R.id.list);
//		list.setAdapter(listAdapter);
//		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//			@Override
//			public void onItemClick(AdapterView<?> parent, View view,
//									int position, long id) {
//				Toast.makeText(MainActivity.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
//			}
//		});

	}

}
